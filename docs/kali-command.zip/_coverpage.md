<!-- _coverpage.md -->

![logo](https://cdn.jsdelivr.net/gh/obentnet/kali-command/cdn/images/logo.png)

# Kali宝典 <small>build.</small>  
源于2021

> 记录kali工具使用的笔记

- kali学的好,牢饭吃得早


[Get Started](#前言)
[给个star~](https://github.com/obentnet/kali-command)
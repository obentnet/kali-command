# thcping6
<warning style="color:red;">本页因撰写者没有ipv6地址,所以本页暂无教程</warning>  
如果您有意愿，请联系 obent@qq.com 来参与编写。  
鸣谢列表一定会有你！